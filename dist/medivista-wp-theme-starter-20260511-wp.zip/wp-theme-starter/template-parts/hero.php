<section class="hero-banner hero-banner-slider action-slider" data-action-slider data-autoplay="6500" aria-label="MEDIVISTA hero banner slides">
  <div class="action-slides">
    <article class="action-slide hero-slide hero-slide-blue is-active" data-slide style="--hero-product-image: url('<?php echo esc_url(get_template_directory_uri() . '/assets/images/products/cellexor-re-tone.webp'); ?>');">
      <div class="container hero-layout">
        <div class="hero-content">
          <p class="eyebrow">Global Medical Aesthetic B2B</p>
          <h1>Professional aesthetic solutions for global partners.</h1>
          <p class="lead">MEDIVISTA connects clinics, distributors, and brand partners with carefully curated Korean aesthetic product information and inquiry-first support.</p>
          <div class="button-row"><a class="btn primary" href="<?php echo esc_url(home_url('/products/')); ?>">View Products</a><a class="btn secondary" href="<?php echo esc_url(home_url('/contact/')); ?>">Request Inquiry</a></div>
          <div class="hero-metrics" aria-label="MEDIVISTA site highlights"><span><strong>115</strong> catalog items</span><span><strong>8</strong> target markets</span><span><strong>3</strong> distribution zones</span></div>
        </div>
        <figure class="hero-visual"><img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/products/cellexor-re-tone.webp'); ?>" alt="CELLEXOR Re:Tone product"><span>MEDIVISTA B2B</span></figure>
      </div>
    </article>
    <article class="action-slide hero-slide hero-slide-gold" data-slide style="--hero-product-image: url('<?php echo esc_url(get_template_directory_uri() . '/assets/images/products/rejuran-healer.webp'); ?>');">
      <div class="container hero-layout">
        <div class="hero-content">
          <p class="eyebrow">Korean Aesthetic Catalog</p>
          <h1>Organized product intelligence for B2B decisions.</h1>
          <p class="lead">Explore category-led information for toxins, fillers, boosters, biostimulators, lipolysis, exosomes, and professional cosmetic concepts.</p>
          <div class="button-row"><a class="btn primary" href="<?php echo esc_url(home_url('/products/')); ?>">Browse Catalog</a><a class="btn secondary" href="<?php echo esc_url(home_url('/contact/')); ?>">Request Information</a></div>
          <div class="hero-metrics" aria-label="Catalog highlights"><span><strong>9</strong> product categories</span><span><strong>114</strong> product images</span><span><strong>EN</strong> first copy</span></div>
        </div>
        <figure class="hero-visual"><img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/products/rejuran-healer.webp'); ?>" alt="Rejuran Healer product"><span>Catalog Review</span></figure>
      </div>
    </article>
    <article class="action-slide hero-slide hero-slide-brand" data-slide style="--hero-product-image: url('<?php echo esc_url(get_template_directory_uri() . '/assets/images/products/cellexor-re-tone.webp'); ?>');">
      <div class="container hero-layout">
        <div class="hero-content">
          <p class="eyebrow">CELLEXOR Re:Tone</p>
          <h1>Own-brand beauty science with premium presentation.</h1>
          <p class="lead">CELLEXOR is positioned through safe, professional aesthetic care language and a brand-focused inquiry path for global partners.</p>
          <div class="button-row"><a class="btn primary" href="<?php echo esc_url(home_url('/brands/')); ?>">View Brand</a><a class="btn secondary" href="<?php echo esc_url(home_url('/contact/')); ?>">Brand Inquiry</a></div>
          <div class="hero-metrics" aria-label="Brand highlights"><span><strong>01</strong> own brand</span><span><strong>B2B</strong> partner focus</span><span><strong>Care</strong> safe wording</span></div>
        </div>
        <figure class="hero-visual"><img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/products/cellexor-re-tone.webp'); ?>" alt="CELLEXOR Re:Tone product"><span>Own Brand</span></figure>
      </div>
    </article>
    <article class="action-slide hero-slide hero-slide-network" data-slide style="--hero-product-image: url('<?php echo esc_url(get_template_directory_uri() . '/assets/images/products/the-chaeum-premium-no-3.webp'); ?>');">
      <div class="container hero-layout">
        <div class="hero-content">
          <p class="eyebrow">Global Network</p>
          <h1>Market-ready communication across key regions.</h1>
          <p class="lead">The site supports partner discovery across the United States, China, Oceania, and Southeast Asia with clear product and contact routes.</p>
          <div class="button-row"><a class="btn primary" href="#global-network">View Network</a><a class="btn secondary" href="<?php echo esc_url(home_url('/contact/')); ?>">Contact Us</a></div>
          <div class="hero-metrics" aria-label="Network highlights"><span><strong>8</strong> target markets</span><span><strong>3</strong> distribution zones</span><span><strong>4</strong> regions</span></div>
        </div>
        <figure class="hero-visual"><img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/products/the-chaeum-premium-no-3.webp'); ?>" alt="The Chaeum Premium No.3 product"><span>Key Markets</span></figure>
      </div>
    </article>
    <article class="action-slide hero-slide hero-slide-inquiry" data-slide style="--hero-product-image: url('<?php echo esc_url(get_template_directory_uri() . '/assets/images/products/botulax-100units.webp'); ?>');">
      <div class="container hero-layout">
        <div class="hero-content">
          <p class="eyebrow">Inquiry-First Support</p>
          <h1>From product review to professional follow-up.</h1>
          <p class="lead">Partners can scan categories, select product interests, and open a prepared WhatsApp or contact-form inquiry for fast communication.</p>
          <div class="button-row"><a class="btn primary" href="<?php echo esc_url(home_url('/contact/')); ?>">Start Inquiry</a><a class="btn secondary" href="#" data-whatsapp>WhatsApp</a></div>
          <div class="hero-metrics" aria-label="Inquiry highlights"><span><strong>Form</strong> ready</span><span><strong>WA</strong> connected</span><span><strong>Inquiry</strong> only</span></div>
        </div>
        <figure class="hero-visual"><img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/products/botulax-100units.webp'); ?>" alt="Botulax 100 Units product"><span>Partner Inquiry</span></figure>
      </div>
    </article>
  </div>
  <div class="slider-controls hero-controls" aria-label="Hero slider controls">
    <button type="button" data-slider-prev aria-label="Previous hero slide"><span class="slider-control-icon" aria-hidden="true">&lt;</span><span class="sr-only">Previous hero slide</span></button>
    <div class="slider-dots" data-slider-dots></div>
    <button type="button" data-slider-next aria-label="Next hero slide"><span class="slider-control-icon" aria-hidden="true">&gt;</span><span class="sr-only">Next hero slide</span></button>
  </div>
</section>
